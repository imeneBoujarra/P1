import React from 'react';

import Scan from './Scan';
import { Route, Router, Routes } from 'react-router-dom';


const Icons = () => {

  <Router>
      <Routes>
      <Route path="/admin/icons" element={<Scan />} />
      </Routes>
    </Router>
  
};

export default Icons;
