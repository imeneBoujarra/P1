import React, { useState, useEffect } from 'react';
import QRScanner from './Scanner/QRScanner';
import Modal from 'react-bootstrap/Modal';
import Btn from './Scanner/Button';
import Button from 'react-bootstrap/Button';
import { Col, Row } from 'reactstrap';
import RoomInfo from './RoomInfo'; // Import the RoomInfo component
import { getServerRoomByQrCode } from 'services/serverRoomService';
import ScanInfo from './ScanInfo';

const Scan = () => {
  const [isOpen, setOpen] = useState(false);
  const [serverRoomData, setServerRoomData] = useState(null);
  const [qrCode, setQrCode] = useState('');

  const openModal = () => {
    setOpen(true);
  };

  const closeModal = () => {
    setOpen(false);
  };



  useEffect(() => {
    const asyncFn = async () => {
      if (qrCode) {
        try {
          console.log("QR Code:", qrCode);
          const response = await getServerRoomByQrCode(qrCode); // Await the promise here
          setServerRoomData(response);
          console.log("Fetched server room:", response);
        } catch (error) {
          console.error('Error fetching server room data:', error);
        }
      }
    };
    asyncFn();
  }, [qrCode]);


  const onScan = (onScan) => {
    setQrCode(onScan);
    console.log("On Scan returned", onScan);
  }


  return (
    <div className="content">
      <Row>
        <Col md="12">
          <div className="appContainer">
            <div className="main">
              <ScanInfo/>
              <Btn text="Scan QR Code" onClick={openModal} />
            </div>
            <Modal show={isOpen} onHide={closeModal} centered>
              <Modal.Header closeButton>
                <Modal.Title>Scan QR Code</Modal.Title>
              </Modal.Header>
              <Modal.Body>
              <QRScanner onScan ={onScan}/>
               
              </Modal.Body>
              <Modal.Footer>
                <Button variant="secondary" onClick={closeModal}>
                  Close
                </Button>
              </Modal.Footer>
            </Modal>

          </div>
           {/* Render RoomInfo outside the modal */}
      <div className="roomInfoContainer">
        {serverRoomData && (
          <RoomInfo roomData={serverRoomData} />
        )}
         </div>
        </Col>
      </Row>
     
     
    </div>
  );
};

export default Scan;
