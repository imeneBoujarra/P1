import React from 'react';
import { Card, CardBody, CardTitle, CardText } from 'reactstrap';

const ScanInfo = () => {
  return (
    <Card>
      <CardBody>
        <CardTitle tag="h5">Check  Room Server</CardTitle>
        <CardText>
          <p>Welcome to the QR code scanning page! Follow the instructions below to successfully scan the QR code of the Room Server :</p>
          <ul>
            <li>Ensure your camera is clean and unobstructed.</li>
            <li>Hold the QR code steady in front of the camera.</li>
            <li>Wait for the scanner to detect and process the QR code.</li>
            <li>Once detected, the scanned information will be displayed.</li>
          </ul>
          <p>If you encounter any issues, please try again or contact support for assistance.</p>
        </CardText>
      </CardBody>
    </Card>
  );
};

export default ScanInfo;
