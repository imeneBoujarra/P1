// routes.js
import Dashboard from "views/Dashboard.js";
import Map from "views/Map.js";
import Scan from "views/Scan";
import TableList from "views/TableList.js";
import UserProfile from "views/UserProfile.js";
import AddServerRoom from "views/AddServerRoom.js";

export const getRoutes = (role) => {
  const routes = [
    {
      path: "/dashboard",
      name: "Home Page",
      rtlName: "لوحة القيادة",
      icon: "tim-icons icon-istanbul",
      component: <Dashboard />,
      layout: "/admin",
    },
    {
      path: "/icons",
      name: "Room Control",
      rtlName: "الرموز",
      icon: "tim-icons icon-badge",
      component: <Scan />,
      layout: "/admin",
    },
    {
      path: "/map",
      name: "View Historical",
      rtlName: "خرائط",
      icon: "tim-icons icon-pin",
      component: <Map />,
      layout: "/admin",
    },
  ];

  if (role === "Admin") {
    routes.push(
      {
        path: "/serverRooms",
        name: "Manage Room",
        rtlName: "إخطارات",
        icon: "tim-icons icon-bell-55",
        component: <AddServerRoom />,
        layout: "/admin",
      },
      {
        path: "/user-profile",
        name: "Add a User",
        rtlName: "ملف تعريفي للمستخدم",
        icon: "tim-icons icon-single-02",
        component: <UserProfile />,
        layout: "/admin",
      },
      {
        path: "/tables",
        name: "User Management",
        rtlName: "قائمة الجدول",
        icon: "tim-icons icon-align-center",
        component: <TableList />,
        layout: "/admin",
      }
    );
  }

  return routes;
};
