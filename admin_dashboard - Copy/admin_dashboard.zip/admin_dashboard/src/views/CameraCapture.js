import React, { useState } from 'react';
import ImagePreview from './ImagePreview';
import axios from 'axios';
import Camera from 'react-html5-camera-photo';
import 'react-html5-camera-photo/build/css/index.css';

const CameraCapture = ({ verifyType, roomData, savePhotoPath }) => {
  const [dataUri, setDataUri] = useState('');

  const handleSavePhoto = async (dataUri) => {
    if (!dataUri) {
      console.error('No photo data available to save.');
      return;
    }
    try {
      const payload = {
        photo: dataUri,
        roomId: roomData.id_Room,
        verifyType: verifyType
      };

      const response = await axios.post('http://localhost:5010/api/photos/SavePhoto', payload, {
        headers: {
          'Content-Type': 'application/json'
        }
      });

      const photoPath = response.data.photoPath;
      console.log('Photo saved at:', photoPath);
      savePhotoPath(verifyType, photoPath); // Pass both verifyType and path
    } catch (error) {
      console.error('Error saving photo:', error);
    }
  };

  function handleTakePhotoAnimationDone(dataUri) {
    setDataUri(dataUri);
    handleSavePhoto(dataUri);
  }

  const isFullscreen = false;
  return (
    <div>
      <h5>Capture Picture for {verifyType}</h5>
      <div>
        {dataUri ? (
          <ImagePreview dataUri={dataUri} isFullscreen={isFullscreen} />
        ) : (
          <Camera
            onTakePhotoAnimationDone={handleTakePhotoAnimationDone}
            isFullscreen={isFullscreen}
          />
        )}
      </div>
    </div>
  );
};

export default CameraCapture;
