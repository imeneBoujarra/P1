import React, { useState, useEffect } from "react";
import {
  Card,
  CardHeader,
  CardBody,
  Table,
  Row,
  Col,
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
} from "reactstrap";
import axios from 'axios';

function formatDate(dateString) {
  if (!dateString) return 'Invalid Date';
  
  const date = new Date(dateString);
  if (isNaN(date.getTime())) return 'Invalid Date';
  
  const options = {
    month: "short",
    day: "2-digit",
    year: "numeric",
    hour: "numeric",
    minute: "numeric",
  };
  return new Intl.DateTimeFormat("en-US", options).format(date);
}

function Map() {
  const [historicals, setHistoricals] = useState([]); // Set initial state as an empty array
  const [selectedFolder, setSelectedFolder] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [images, setImages] = useState([]);

  useEffect(() => {
    const fetchHistoricals = async () => {
      try {
        const response = await axios.get('http://localhost:5010/api/Historical');
        console.log(response.data);

        // Check if the response data is an array
        if (Array.isArray(response.data)) {
          setHistoricals(response.data);
        } else if (response.data && response.data.$values) {
          setHistoricals(response.data.$values); // Adjust based on your API response structure
        } else {
          console.error('Unexpected response format:', response.data);
        }
      } catch (error) {
        console.error('Error fetching historicals:', error);
      }
    };

    fetchHistoricals();
  }, []);

  const toggleModal = () => setModalOpen(!modalOpen);

  const handleFolderClick = async (folder) => {
    try {
      const imageMappings = Object.entries(folder.checklist)
        .filter(([key, value]) => typeof value === 'string' && (value.startsWith('http') || value.startsWith('/images')))
        .map(([key, value]) => ({
          attribute: key,
          url: `http://localhost:5010/api/photos/GetImage?imageName=${encodeURIComponent(value.split('/').pop())}`
        }));
      
      const validImageMappings = await Promise.all(
        imageMappings.map(async (mapping) => {
          try {
            const response = await axios.get(mapping.url);
            if (response.status === 200) {
              return mapping;
            }
          } catch (error) {
            console.error(`Error fetching image from ${mapping.url}:`, error);
            return null;
          }
        })
      );

      setImages(validImageMappings.filter((mapping) => mapping !== null));
      setSelectedFolder(folder);
      toggleModal();
    } catch (error) {
      console.error('Error handling folder click:', error);
    }
  };

  return (
    <>
      <div className="content">
        <Row>
          <Col md="12">
            <Card className="card-plain">
              <CardHeader>Folders</CardHeader>
              <CardBody>
                <Table responsive>
                  <thead className="text-primary">
                    <tr>
                      <th>ID</th>
                      <th>Date</th>
                      <th>User Name</th>
                      <th>Pictures</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {historicals.map((historical) => (
                      <tr key={historical.id}>
                        <td>{historical.id}</td>
                        <td>{formatDate(historical.dateTime)}</td>
                        <td>{historical.user.name.toUpperCase() ?? 'Unknown'}</td>
                        <td>{historical.checklist ? Object.values(historical.checklist).filter(value => typeof value === 'string' && value.startsWith('/images')).length : 0}</td>
                        <td>
                          <Button
                            color="primary"
                            onClick={() => handleFolderClick(historical)}
                          >
                            View Pictures
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </div>
      <Modal isOpen={modalOpen} toggle={toggleModal} size="xl">
  <ModalHeader toggle={toggleModal}>Pictures</ModalHeader>
  <ModalBody>
    {selectedFolder && (
      <>
        <h5>User ID: {selectedFolder.user?.id_user ?? 'Unknown'}</h5>
        <hr />
        <div style={{ display: "flex", flexWrap: "wrap" }}>
          {images.length > 0 ? (
            images.map((image, index) => (
              <div key={index} style={{ width: "calc(33.33% - 10px)", margin: "5px" }}>
                <h6 style={{ color: "black" }}>{image.attribute}</h6>
                <img
                  src={image.url}
                  alt={`Picture ${index + 1}`}
                  style={{ maxWidth: "100%", marginBottom: "5px" }}
                />
              </div>
            ))
          ) : (
            <p>No images available.</p>
          )}
        </div>
      </>
    )}
  </ModalBody>
  <ModalFooter>
    <Button color="secondary" onClick={toggleModal}>
      Close
    </Button>
  </ModalFooter>
</Modal>

    </>
  );
}

export default Map;
