import React from "react";
import { NavLink } from "react-router-dom";
import { Nav } from "reactstrap";

const Sidebar = (props) => {
  return (
    <div className="sidebar">
      <div className="sidebar-wrapper">
        <Nav>
          {props.routes.map((prop, key) => {
            return (
              <li key={key}>
                <NavLink to={prop.layout + prop.path}>
                  <i className={prop.icon} />
                  <p>{prop.name}</p>
                </NavLink>
              </li>
            );
          })}
        </Nav>
      </div>
    </div>
  );
};

export default Sidebar;
