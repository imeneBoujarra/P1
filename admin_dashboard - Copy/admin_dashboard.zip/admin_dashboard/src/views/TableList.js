import React, { useState, useEffect } from "react";
import {
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Table,
  Row,
  Col,
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
} from "reactstrap";
import axios from "axios";
import { Link } from "react-router-dom";
import { FaEye, FaEdit, FaTrash, FaUserPlus } from "react-icons/fa";
import './styles/user.scss'

function Tables() {
  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [editUserData, setEditUserData] = useState(null);

  const toggleModal = () => setModalOpen(!modalOpen);
  const toggleEditModal = () => setEditModalOpen(!editModalOpen);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const response = await axios.get("http://localhost:5010/api/Users");
      console.log("fetched data", response.data);
      const users = response.data.$values || [];
      setUsers(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      setUsers([]);
    }
  };

  const handleViewDetails = (user) => {
    setSelectedUser(user);
    toggleModal();
  };

  const handleDeleteUser = async (userId) => {
    try {
      await axios.delete(`http://localhost:5010/api/Users/RemoveUserbyId/${userId}`);
      setUsers(users.filter((user) => user.id_user !== userId));
    } catch (error) {
      console.error("Error deleting user:", error);
    }
  };

  const handleEditUser = (user) => {
    setEditUserData(user);
    toggleEditModal();
  };

  const handleEditInputChange = (e) => {
    const { name, value } = e.target;
    setEditUserData({
      ...editUserData,
      [name]: value
    });
  };

  const handleUpdateUser = async () => {
    try {
      await axios.put(`http://localhost:5010/api/Users/UpdateUser/${editUserData.id_user}`, editUserData);
      fetchUsers();
      toggleEditModal();
    } catch (error) {
      console.error("Error updating user:", error);
    }
  };

  const renderUserDetails = () => {
    if (!selectedUser) return null;
    return (
      <div>
        <p>First Name: {selectedUser.first_name}</p>
        <p>Last Name: {selectedUser.Name}</p>
        <p>Email: {selectedUser.email}</p>
        <p>Phone Number: {selectedUser.Tel}</p>
        <p>Password: {selectedUser.Password}</p>
        <p>Role: {selectedUser.Role}</p>
      </div>
    );
  };

  const renderEditUserForm = () => {
    if (!editUserData) return null;
    return (
      <div>
        <label>First Name:</label>
        <input type="text" name="first_name" value={editUserData.first_name} onChange={handleEditInputChange} />
        <label>Last Name:</label>
        <input type="text" name="Name" value={editUserData.Name} onChange={handleEditInputChange} />
        <label>Email:</label>
        <input type="email" name="email" value={editUserData.email} onChange={handleEditInputChange} />
        <label>Phone Number:</label>
        <input type="text" name="Tel" value={editUserData.Tel} onChange={handleEditInputChange} />
        <label>Password:</label>
        <input type="password" name="Password" value={editUserData.Password} onChange={handleEditInputChange} />
        <label>Role:</label>
        <select name="Role" value={editUserData.Role} onChange={handleEditInputChange}>
          <option value="Technician">Technician</option>
          <option value="Admin">Admin</option>
        </select>
        <Button color="primary" onClick={handleUpdateUser}>Save</Button>
      </div>
    );
  };

  return (
    <>
      <div className="content">
        <Row>
          <Col md="12">
            <Card>
              <CardHeader>
                <Row>
                  <Col>
                    <CardTitle tag="h4">Users</CardTitle>
                  </Col>
                  <Col className="text-end">
                    <Link to="http://localhost:3000/admin/user-profile">
                      <Button color="success">
                        <FaUserPlus /> Add User
                      </Button>
                    </Link>
                  </Col>
                </Row>
              </CardHeader>
              <CardBody>
                <Table className="tablesorter" responsive>
                  <thead className="text-primary">
                    <tr>
                      <th>Name</th>
                      <th>First Name</th>
                      <th>Email</th>
                      <th className="text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map((user) => (
                      <tr key={user.id_user}>
                        <td>{user.Name}</td>
                        <td>{user.first_name}</td>
                        <td>{user.email}</td>
                        <td className="text-center">
                          <Button
                            color="info"
                            onClick={() => handleViewDetails(user)}
                            className="btn"                          >
                            <FaEye />
                          </Button>
                          <Button
                            color="warning"
                            onClick={() => handleEditUser(user)}
                            className="btn"                          >
                            <FaEdit />
                          </Button>
                          <Button
                            color="danger"
                            onClick={() => handleDeleteUser(user.id_user)}
                            className="btn"
                          >
                            <FaTrash />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </div>

      <Modal isOpen={modalOpen} toggle={toggleModal}>
        <ModalHeader toggle={toggleModal}>User Details</ModalHeader>
        <ModalBody>{renderUserDetails()}</ModalBody>
        <ModalFooter>
          <Button className="btn" color="secondary" onClick={toggleModal}>
            Close
          </Button>
        </ModalFooter>
      </Modal>

      <Modal isOpen={editModalOpen} toggle={toggleEditModal}>
        <ModalHeader toggle={toggleEditModal}>Edit User</ModalHeader>
        <ModalBody>{renderEditUserForm()}</ModalBody>
        <ModalFooter>
          <Button className="btn" color="secondary" onClick={toggleEditModal}>
            Cancel
          </Button>
        </ModalFooter>
      </Modal>
    </>
  );
}

export default Tables;
