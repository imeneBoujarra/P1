import React, { useState } from "react";
import {
  Card,
  CardHeader,
  CardBody,
  Form,
  FormGroup,
  Label,
  Input,
  Button,
  Row,
  Col,
  Alert,
} from "reactstrap";
import axios from "axios";
import Swal from "sweetalert2";
import withReactContent from "sweetalert2-react-content";
const MySwal = withReactContent(Swal);

function AddUser() {
  const [userData, setUserData] = useState({
    name: "",
    email: "",
    firstName: "",
    lastName: "",
    role: "Technician",
    password: "",
    confirmPassword: "",
    phoneNumber: ""
  });
  const [error, setError] = useState(null);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUserData({
      ...userData,
      [name]: value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Clear previous messages
    setError(null);

    try {
      const response = await axios.post("http://localhost:5010/api/Users/Add users", {
        Name: userData.name,
        pass: userData.password,
        confirmPass: userData.confirmPassword,
        f_n: userData.firstName,
        r: userData.role,
        ph: userData.phoneNumber,
        mail: userData.email,
      });

      if (response.status === 200) {
        // Display success alert
        MySwal.fire({
          title: "Success",
          text: "User added successfully!",
          icon: "success",
          confirmButtonText: "OK"
        });

        // Reset form fields
        setUserData({
          name: "",
          email: "",
          firstName: "",
          lastName: "",
          role: "Technician",
          password: "",
          confirmPassword: "",
          phoneNumber: ""
        });
      }
    } catch (error) {
      if (error.response) {
        setError(error.response.data);
      } else {
        setError("An error occurred while adding the user.");
      }
    }
  };

  return (
    <Col md="8">
      <Card>
        <CardHeader>
          <h5 className="title">Add a user</h5>
        </CardHeader>
        <CardBody>
          <Form onSubmit={handleSubmit}>
            <Row>
              <Col className="pl-md-1" md="9">
                <FormGroup>
                  <Label>Email address</Label>
                  <Input
                    placeholder="Example@gmail.com"
                    type="email"
                    value={userData.email}
                    name="email"
                    onChange={handleInputChange}
                  />
                </FormGroup>
              </Col>
            </Row>
            <Row>
              <Col className="pr-md-1" md="6">
                <FormGroup>
                  <Label>First Name</Label>
                  <Input
                    placeholder="First Name"
                    type="text"
                    value={userData.firstName}
                    name="firstName"
                    onChange={handleInputChange}
                  />
                </FormGroup>
              </Col>
              <Col className="pl-md-1" md="6">
                <FormGroup>
                  <Label>Last Name</Label>
                  <Input
                    placeholder="Last Name"
                    type="text"
                    value={userData.lastName}
                    name="lastName"
                    onChange={handleInputChange}
                  />
                </FormGroup>
              </Col>
            </Row>
            <Row>
              <Col md="12">
                <FormGroup>
                  <Label>Role: Admin / Technician</Label>
                  <Input
                    type="select"
                    value={userData.role}
                    name="role"
                    onChange={handleInputChange}
                  >
                    <option value="Technician">Technician</option>
                    <option value="Admin">Admin</option>
                  </Input>
                </FormGroup>
              </Col>
            </Row>
            <Row>
              <Col className="pr-md-1" md="4">
                <FormGroup>
                  <Label>Password</Label>
                  <Input
                    placeholder="Password"
                    type="password"
                    value={userData.password}
                    name="password"
                    onChange={handleInputChange}
                  />
                </FormGroup>
              </Col>
              <Col className="px-md-1" md="4">
                <FormGroup>
                  <Label>Confirm Password</Label>
                  <Input
                    placeholder="Confirm Password"
                    type="password"
                    value={userData.confirmPassword}
                    name="confirmPassword"
                    onChange={handleInputChange}
                  />
                </FormGroup>
              </Col>
              <Col className="pl-md-1" md="4">
                <FormGroup>
                  <Label>Phone number</Label>
                  <Input
                    placeholder="Phone Number +216"
                    type="text"
                    value={userData.phoneNumber}
                    name="phoneNumber"
                    onChange={handleInputChange}
                  />
                </FormGroup>
              </Col>
            </Row>
            {error && <Alert color="danger">{error}</Alert>}
            <Button className="btn-fill" color="primary" type="submit">
              Save
            </Button>
          </Form>
        </CardBody>
      </Card>
    </Col>
  );
}

function UserProfile() {
  return (
    <>
      <div className="content">
        <Row>
          <Col md="4">
            <Card className="card-user">
              <CardBody>
                <div className="author">
                  <div className="block block-one" />
                  <div className="block block-two" />
                  <div className="block block-three" />
                  <div className="block block-four" />
                  <a href="#pablo" onClick={(e) => e.preventDefault()}>
                    <img
                      alt="..."
                      className="avatar"
                      src={require("assets/img/anime3.png")}
                    />
                    <h5 className="title">Abdelaziz Marzouk</h5>
                  </a>
                  <p className="description">Admin Work in the IT department</p>
                </div>
                <div className="card-description">
                  "Please, Mr. Marzouk, ensure that you check this platform daily to ensure that our servers and services are working well and as planned. Many thanks for your hard work in keeping this company the best."
                </div>
              </CardBody>
            </Card>
          </Col>
          <AddUser />
        </Row>
      </div>
    </>
  );
}

export default UserProfile;
