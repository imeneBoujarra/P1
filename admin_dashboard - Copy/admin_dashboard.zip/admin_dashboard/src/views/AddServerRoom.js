import React, { useState } from 'react';
import {
  Card,
  CardBody,
  FormGroup,
  Label,
  Input,
  Row,
  Col,
  CustomInput,
  Button,
  Alert,
} from 'reactstrap';
import axios from 'axios';

const AddServerRoom = () => {
  const [serverRoomData, setServerRoomData] = useState({
    roomNumber: 0,
    serversNumbers: 0,
    machines: 0,
    verifyHeat: false,
    verifySwitchers: false,
    verifyBackbone: false,
    verifyVentilation: false,
    verifySecurity: false,
    verifyStorage: false,
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleChange = (event) => {
    const { name, value, checked, type } = event.target;
    let inputValue;
  
    if (type === 'checkbox') {
      inputValue = checked;
    } else if (type === 'number') {
      inputValue = isNaN(parseInt(value)) ? 0 : parseInt(value);
    } else {
      inputValue = value;
    }
  
    setServerRoomData({
      ...serverRoomData,
      [name]: inputValue,
    });
  };
  

  const handleCreateServerRoom = async () => {
    try {
      const response = await axios.post(
        'http://localhost:5010/CreateServerRoom',
        serverRoomData
      );
      setSuccess('Server room created successfully!');
      setServerRoomData({
        roomNumber: 0,
        serversNumbers: 0,
        machines: 0,
        verifyHeat: false,
        verifySwitchers: false,
        verifyBackbone: false,
        verifyVentilation: false,
        verifySecurity: false,
        verifyStorage: false,
      });
    } catch (error) {

      setError('Error creating server room' );
    }
  };
  

  return (
    <div className="content">
      <Row>
        <Col md="12">
          <Card>
            <CardBody>
              <h4 className="card-title">Add Server Room</h4>
              {error && <Alert color="danger">{error}</Alert>}
              {success && <Alert color="success">{success}</Alert>}
              <FormGroup>
                <Label for="roomNumber">Room Number:</Label>
                <Input
                  type="number"
                  id="roomNumber"
                  name="roomNumber"
                  value={serverRoomData.roomNumber}
                  onChange={handleChange}
                />
              </FormGroup>
              <FormGroup>
                <Label for="serversNumbers">Servers Numbers:</Label>
                <Input
                  type="number"
                  id="serversNumbers"
                  name="serversNumbers"
                  value={serverRoomData.serversNumbers}
                  onChange={handleChange}
                />
              </FormGroup>
              <FormGroup>
                <Label for="machines">Machines:</Label>
                <Input
                  type="number"
                  id="machines"
                  name="machines"
                  value={serverRoomData.machines}
                  onChange={handleChange}
                />
              </FormGroup>

               {/* Checkboxes */}
               <FormGroup check>
                <CustomInput
                  type="checkbox"
                  id="verifyHeat"
                  name="verifyHeat"
                  label="Verify Heat"
                  checked={serverRoomData.verifyHeat}
                  onChange={handleChange}
                />
              </FormGroup>
              <FormGroup check>
                <CustomInput
                  type="checkbox"
                  id="verifySwitchers"
                  name="verifySwitchers"
                  label="Verify Switchers"
                  checked={serverRoomData.verifySwitchers}
                  onChange={handleChange}
                />
              </FormGroup>
              <FormGroup check>
                <CustomInput
                  type="checkbox"
                  id="verifyBackbone"
                  name="verifyBackbone"
                  label="Verify Backbone"
                  checked={serverRoomData.verifyBackbone}
                  onChange={handleChange}
                />
              </FormGroup>
              <FormGroup check>
                <CustomInput
                  type="checkbox"
                  id="verifyVentilation"
                  name="verifyVentilation"
                  label="Verify Ventilation"
                  checked={serverRoomData.verifyVentilation}
                  onChange={handleChange}
                />
              </FormGroup>
              <FormGroup check>
                <CustomInput
                  type="checkbox"
                  id="verifySecurity"
                  name="verifySecurity"
                  label="Verify Security"
                  checked={serverRoomData.verifySecurity}
                  onChange={handleChange}
                />
              </FormGroup>
              <FormGroup check>
                <CustomInput
                  type="checkbox"
                  id="verifyStorage"
                  name="verifyStorage"
                  label="Verify Storage"
                  checked={serverRoomData.verifyStorage}
                  onChange={handleChange}
                />
              </FormGroup>

              {/* Create Button */}
              <Button color="primary" onClick={handleCreateServerRoom}>
                Create Server Room
              </Button>
            </CardBody>
          </Card>
        </Col>
      </Row>
    </div>
  );
};

export default AddServerRoom;
