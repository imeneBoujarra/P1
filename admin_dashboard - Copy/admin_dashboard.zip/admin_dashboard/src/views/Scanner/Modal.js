import React from 'react';
import Rodal from 'rodal';
import 'rodal/lib/rodal.css';
import './Modal.scss';

const customStyles = {
  height: 'auto',
  bottom: 'auto',
  top: '20%',
};

const Modal = ({ isOpen, title, closeModal, children }) => {
  return (
    <Rodal
      visible={isOpen}
      animation="zoom"
      onClose={closeModal}
      customStyles={customStyles}
    >
      <div className="modal">
        <div className="modal__header">
          <div className="modal__title">
            <p>{title}</p>
          </div>
          <button className="modal__close-btn" onClick={closeModal}>&times;</button>
        </div>
        <div className="modal__content">{children}</div>
      </div>
    </Rodal>
  );
};

export default Modal;
