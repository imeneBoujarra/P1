import React, { useState } from 'react';
import {
  Card,
  CardBody,
  FormGroup,
  Label,
  Input,
  Button,
  Alert,
} from 'reactstrap';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const [credentials, setCredentials] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleChange = (event) => {
    const { name, value } = event.target;
    setCredentials({
      ...credentials,
      [name]: value,
    });
  };

  const handleLogin = async () => {
    setError(''); // Clear previous errors
    try {
      if (!credentials.email || !credentials.password) {
        setError('Please enter email and password');
        return;
      }

      const response = await axios.post(
        'http://localhost:5010/api/Users/Login',
        credentials
      );

      // Store user data in localStorage
      localStorage.setItem('isAuthenticated', true);
      localStorage.setItem('user', JSON.stringify(response.data));
      localStorage.setItem('role', response.data.role);

      // Navigate to the /admin route
      navigate('/admin');
    } catch (error) {
      console.error('Error logging in:', error);
      setError('Invalid email or password');
    }
  };

  return (
    <div className="d-flex justify-content-center align-items-center vh-100">
      <Card style={{ width: '400px' }}>
        <CardBody>
          <h4 className="card-title text-center">Login</h4>
          {error && <Alert color="danger">{error}</Alert>}
          <FormGroup>
            <Label for="email">Email:</Label>
            <Input
              type="email"
              id="email"
              name="email"
              placeholder="Enter your email"
              value={credentials.email}
              onChange={handleChange}
            />
          </FormGroup>
          <FormGroup>
            <Label for="password">Password:</Label>
            <Input
              type="password"
              id="password"
              name="password"
              placeholder="Enter your password"
              value={credentials.password}
              onChange={handleChange}
            />
          </FormGroup>
          <div className="text-center">
            <Button color="primary" onClick={handleLogin}>
              Login
            </Button>
          </div>
        </CardBody>
      </Card>
    </div>
  );
};

export default Login;
