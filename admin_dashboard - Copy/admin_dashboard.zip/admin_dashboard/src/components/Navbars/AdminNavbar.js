import React, { useState } from 'react';
import classNames from 'classnames';
import {
  Button,
  Collapse,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  UncontrolledDropdown,
  Input,
  InputGroup,
  NavbarBrand,
  Navbar,
  NavLink,
  Nav,
  Container,
  Modal,
  NavbarToggler,
  ModalHeader,
} from 'reactstrap';
import { useNavigate } from 'react-router-dom';

function AdminNavbar(props) {
  const [collapseOpen, setCollapseOpen] = useState(false);
  const [modalSearch, setModalSearch] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(
    localStorage.getItem('isAuthenticated') === 'true'
  );
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('isAuthenticated');
    localStorage.removeItem('user');
    localStorage.removeItem('role');
    setIsAuthenticated(false);
    navigate('/login'); // Redirect to the login page after logout
  };

  const toggleCollapse = () => {
    setCollapseOpen(!collapseOpen);
  };

  const toggleModalSearch = () => {
    setModalSearch(!modalSearch);
  };

  return (
    <>
      <Navbar
        className={classNames('navbar-absolute', props.color)}
        expand="lg"
      >
        <Container fluid>
          <div className="navbar-wrapper">
            {/* Navbar toggle button */}
            <div
              className={classNames('navbar-toggle d-inline', {
                toggled: props.sidebarOpened,
              })}
            >
              <NavbarToggler onClick={props.toggleSidebar}>
                <span className="navbar-toggler-bar bar1" />
                <span className="navbar-toggler-bar bar2" />
                <span className="navbar-toggler-bar bar3" />
              </NavbarToggler>
            </div>
            <NavbarBrand href="#pablo" onClick={(e) => e.preventDefault()}>
              {props.brandText}
            </NavbarBrand>
          </div>
          {/* Navbar collapse */}
          <Collapse navbar isOpen={collapseOpen}>
            <Nav className="ml-auto" navbar>
              <InputGroup className="search-bar">
                {/* Search button */}
                <Button color="link" onClick={toggleModalSearch}>
                  <i className="tim-icons icon-zoom-split" />
                  <span className="d-lg-none d-md-block">Search</span>
                </Button>
              </InputGroup>
              {/* Notification dropdown */}
              <UncontrolledDropdown nav>
                <DropdownToggle caret color="default" nav>
                  <div className="notification d-none d-lg-block d-xl-block" />
                  <i className="tim-icons icon-sound-wave" />
                  <p className="d-lg-none">Notifications</p>
                </DropdownToggle>
                {/* Notification dropdown menu */}
                <DropdownMenu className="dropdown-navbar" right tag="ul">
                  <NavLink tag="li">
                    <DropdownItem className="nav-item">
                      Pls check the server room number 5 and thx
                    </DropdownItem>
                  </NavLink>
                  {/* Add more notification items here */}
                </DropdownMenu>
              </UncontrolledDropdown>
              {/* Profile dropdown */}
              <UncontrolledDropdown nav>
                <DropdownToggle caret color="default" nav>
                  <div className="photo">
                    <img
                      alt="..."
                      src={require('assets/img/anime3.png')}
                    />
                  </div>
                  <b className="caret d-none d-lg-block d-xl-block" />
                  <p className="d-lg-none">Log out</p>
                </DropdownToggle>
                {/* Profile dropdown menu */}
                <DropdownMenu className="dropdown-navbar" right tag="ul">
                  <NavLink tag="li" to="./src/views/UserProfile.js">
                    <DropdownItem className="nav-item">Profile </DropdownItem>
                  </NavLink>
                  {/* Add more profile menu items here */}
                  <DropdownItem divider tag="li" />
                  {/* Logout action */}
                  <DropdownItem className="nav-item" onClick={handleLogout}>
                    Log out
                  </DropdownItem>
                </DropdownMenu>
              </UncontrolledDropdown>
              <li className="separator d-lg-none" />
            </Nav>
          </Collapse>
        </Container>
      </Navbar>
      {/* Search modal */}
      <Modal
        modalClassName="modal-search"
        isOpen={modalSearch}
        toggle={toggleModalSearch}
      >
        <ModalHeader>
          <Input placeholder="SEARCH" type="text" />
          <button
            aria-label="Close"
            className="close"
            onClick={toggleModalSearch}
          >
            <i className="tim-icons icon-simple-remove" />
          </button>
        </ModalHeader>
      </Modal>
    </>
  );
}

export default AdminNavbar;
