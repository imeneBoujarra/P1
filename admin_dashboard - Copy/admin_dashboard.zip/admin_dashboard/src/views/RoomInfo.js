import React, { useState, useEffect } from 'react';
import { Modal, Button } from 'react-bootstrap';
import CameraCapture from './CameraCapture';
import axios from 'axios';
import Swal from 'sweetalert2';

const RoomInfo = ({ roomData }) => {
  const [modalInfo, setModalInfo] = useState({ show: false, verifyType: '' });
  const [photoPaths, setPhotoPaths] = useState({});
  const [checklist, setChecklist] = useState({
    ServerRoomId: roomData.id_Room,
    HeatPictureUrl: '',
    SwitchersPictureUrl: '',
    Backbone: '',
    Ventilation: '',
    Security: '',
    Storage: '',
    UserId: null // Placeholder for user ID
  });

  // Retrieve and parse the user data from localStorage
  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user'));
    console.log ("user id " , user.user.$id)
    if (user && user.user.$id) {
      setChecklist(prevChecklist => ({
        ...prevChecklist,
        UserId: user.id
      }));
    }
  }, []);

  const handleOpenModal = (verifyType) => {
    setModalInfo({ show: true, verifyType });
  };

  const handleCloseModal = () => {
    setModalInfo({ show: false, verifyType: '' });
  };

  const savePhotoPath = (verifyType, path) => {
    const updatedPhotoPaths = { ...photoPaths, [verifyType]: path };
    setPhotoPaths(updatedPhotoPaths);
    console.log('Photo paths updated:', updatedPhotoPaths);
  };

  const handleCreateChecklist = async () => {
    try {
      const updatedChecklist = {
        ...checklist,
        HeatPictureUrl: photoPaths['Heat'] || '',
        SwitchersPictureUrl: photoPaths['Switchers'] || '',
        Backbone: photoPaths['Backbone'] || '',
        Ventilation: photoPaths['Ventilation'] || '',
        Security: photoPaths['Security'] || '',
        Storage: photoPaths['Storage'] || ''
      };

      console.log('Checklist before sending:', updatedChecklist);
      const response = await axios.post('http://localhost:5010/api/checklist/CreateChecklist', updatedChecklist);
      console.log('Checklist created:', response.data);

      // Clear the photo paths and checklist
      setPhotoPaths({});
      setChecklist({
        ServerRoomId: roomData.id_Room,
        HeatPictureUrl: '',
        SwitchersPictureUrl: '',
        Backbone: '',
        Ventilation: '',
        Security: '',
        Storage: '',
        UserId: checklist.UserId // Retain the user ID
      });

      // Display success message
      Swal.fire({
        icon: 'success',
        title: 'Success',
        text: 'Checklist created successfully!'
      });
    } catch (error) {
      console.error('Error creating checklist:', error);

      // Display error message
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'Failed to create checklist.'
      });
    }
  };

  return (
    <div>
      <h3>Server Room Data:</h3>
      <p>Room Number: {roomData.room_Number}</p>
      <p>Servers: {roomData.servers_Numbers}</p>
      <p>Machines: {roomData.machines}</p>
      
      <h4>Verification</h4>
      {['Heat', 'Switchers', 'Backbone', 'Ventilation', 'Security', 'Storage'].map((type) => (
        <div key={type} style={{ marginBottom: '10px' }}>
          {roomData[`verify${type}`] ? (
            <Button onClick={() => handleOpenModal(type)}>
              Verify {type}
            </Button>
          ) : (
            <p>{type} Verification: Not Required</p>
          )}
          {photoPaths[type] && <p>Photo Path ({type}): {photoPaths[type]}</p>}
        </div>
      ))}
      
      <Modal show={modalInfo.show} onHide={handleCloseModal} centered size="lg">
        <Modal.Header closeButton>
          <Modal.Title>Verify {modalInfo.verifyType}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <CameraCapture verifyType={modalInfo.verifyType} roomData={roomData} savePhotoPath={savePhotoPath} />
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseModal}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>

      <Button onClick={handleCreateChecklist} style={{ marginTop: '20px' }}>
        Create Checklist
      </Button>
    </div>
  );
};

export default RoomInfo;
