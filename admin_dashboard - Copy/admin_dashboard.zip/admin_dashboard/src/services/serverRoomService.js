// src/services/api.js
import axios from 'axios';

const API_BASE_URL = 'http://localhost:5010'; // Replace with your actual API base URL

const api = axios.create({
  baseURL: API_BASE_URL,
});

export const getServerRoomByQrCode = async (qrCode) => {
  try {
    const response = await api.get(`/byqrcode`, {
      params: { qrCode }
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching server room data:', error);
    throw error;
  }
};
